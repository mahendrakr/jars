package com.mha.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mha.mail.service.MailService;

/**
 * Servlet implementation class ForgotPasswordController
 */
public class ForgotPasswordAction extends MhaBaseAction{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ForgotPasswordAction() {
        super();
        // TODO Auto-generated constructor stub
    }


	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String email = request.getParameter("email");
		 
		 RequestDispatcher rd = null;
		 String result = null;
		 if(email!=null) {
			 MailService.sendMail(email, "Password", "<h3>Your password is 123456</h3>");
			 request.getSession().setAttribute("pwd", "enter");
			rd= request.getRequestDispatcher("WEB-INF/html/success.jsp");
			result="success.jsp";
		 }else {
			 result="index.jsp";
		 }
		return result;
	}

}
