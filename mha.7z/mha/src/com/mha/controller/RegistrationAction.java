package com.mha.controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegistrationController
 */
public class RegistrationAction extends MhaBaseAction {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String email = request.getParameter("email");
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String state=request.getParameter("state");
		String country =request.getParameter("country");
		String pincode=request.getParameter("pincode");
		request.getSession().setAttribute("name", name);
		
		return "home.jsp";
	}

}
