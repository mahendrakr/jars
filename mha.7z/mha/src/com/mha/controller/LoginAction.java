package com.mha.controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LonginController
 */

public class LoginAction extends MhaBaseAction {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		 String email = request.getParameter("email");
		 String password = request.getParameter("password");
		 String result=null;
		 if(password.equals("password")) {
			 request.setAttribute("name", "Kalawati");
			 result= "home.jsp";
		 }else {
			 result= "index.html";
		 }
		return result;
	}

}
